<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="x-icon" href="https://cdn-icons-png.flaticon.com/512/197/197722.png">
    <title>Paid_rent</title>
    <style>
         h1{
    color:darkblue;
    font-family: 'Trebuchet MS';
    text-align:center;
}
h1 span{
    color:#d9bc6b;
    font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif
}
.heading{
    font-size:38px;
    text-align: center;
    color:blue;
    font-family:Arial;
   
}
body{
            background:linear-gradient(to bottom, #fefefe 0%, #d1d1d1 33%, #7a7a99 66%, #e6e6e6 100%);
        }
/* .btn{
    font-size:30px;
    width:200px;
    padding:200px;
} */


    </style>
</head>
<body>
    <div class="heading">
    <h1>Flat<span>Easy</span></h1>
    <br>
    <div class="heading">
                  <h3>YOU HAVE PAID YOUR RENT</h3>
     <br>
     <br>
        <!-- <a href="pay_parking.php?rn=$user" class="btn">PARKING ACCESS</a> -->
     </div>
</body>
</html>